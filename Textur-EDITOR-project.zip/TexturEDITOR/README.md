# Textur EDITOR — starter project

This is an Android WebView starter project plus a local pixel-texture generator prototype.

## Build APK
1. Open this folder in Android Studio on a computer.
2. Let Gradle sync (requires internet and Android SDK; compile SDK 35).
3. Build > Build APK(s).
4. The debug APK will normally be under `app/build/outputs/apk/debug/`.

## Important limitations
- No APK has been built or tested in this environment.
- The generator is a deterministic pixel-pattern prototype, not a real generative AI model.
- Export uses JSZip from a CDN, so the first export requires internet.
- The exported `.mcpack` contains a preview PNG and a valid-style manifest, but it does not yet replace vanilla Minecraft textures because the correct asset paths and mappings have not been implemented.
